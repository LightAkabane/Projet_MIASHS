<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
</head>
<body>
    <h1>Enigmatica</h1>
    <div class="session">
    
    <?php
    session_start();
    if (isset($_SESSION['client'])) {
        echo 'Bonjour ' . $_SESSION['client']['prenom'] . ' ' . $_SESSION['client']['nom'];
        echo ' <a href="deconnexion.php"><button>Se déconnecter</button></a>';
        echo ' <a href="panier.php"><button>Mon panier</button></a>';
        echo ' <a href="historique.php"><button>Mon historique</button></a>';
    }
    else{

        echo '<a href="nouveau.php"><button>Sinscrire</button> </a>';
        echo '<a href="connexion.php"><button>Se connecter</button></a>';
    }

?>
</div>
    <table>
        <tr>
            <td>Image du Produit</td>
            <td>Numero Identifiant</td>
            <td>Nom du Personnage</td>
            <td>Stock</td>
            <td>Prix</td>
            <td></td>
        </tr>
        <?php
            include "bd.php";
            $bdd = getBD();
    
            $result = $bdd->query('SELECT url_photo, id_art, nom, quantite, prix FROM Article');
    
            while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                $image = $row['url_photo'];
                $ident = $row['id_art'];
                $nom = $row['nom'];
                $qtt = $row['quantite'];
                $prix = $row['prix'];
                ?>
                <tr>
                    <td><img src="<?php echo $image; ?>" alt="Image du Produit" class="zoom"></td>
                    <td><?php echo $ident; ?></td>
                    <td><?php echo $nom; ?></td>
                    <td><?php echo $qtt; ?></td>
                    <td><?php echo $prix; ?>¥</td>
                    <td><a href="articles/article.php?id_art=<?php echo $ident; ?>">Voir plus</a></td>
                </tr>
                <?php
            }
        ?>
    </table>
    
    <a href="contact/Contact.html"><button>Contactez-moi</button></a>

</body>
</html>
