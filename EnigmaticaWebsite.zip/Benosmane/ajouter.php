<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Ajout en cours....</title>
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
</head>
<?php
session_start();

$id_art = isset($_POST['id_art']) ? $_POST['id_art'] : null;
$quantite_article = isset($_POST['quantite_article']) ? $_POST['quantite_article'] : null;

if ($id_art !== null && $quantite_article !== null) {
    if ($quantite_article >= 0) {
        if (!isset($_SESSION['panier'])) {
            $_SESSION['panier'] = array();
        }

        $article_existe = false;
        foreach ($_SESSION['panier'] as &$article) {
            if ($article['id_art'] === $id_art) {
                $article['quantite'] += $quantite_article;
                $article_existe = true;
                break;
            }
        }

        if (!$article_existe) {
            $nouvel_article = array(
                'id_art' => $id_art,
                'quantite' => $quantite_article
            );
            $_SESSION['panier'][] = $nouvel_article;
        }

        header('Location: index.php');
        exit();
    } else {
        echo "La quantité ne peut pas être négative.";
        header('refresh:2;url=index.php');
    }
} else {
    echo "Problème avec les données du formulaire.";
}
?>
