<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title><?php echo isset($nom) ? $nom : "Article"; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles/monfichier.css" type="text/css" media="screen" />
</head>
<body>
<?php
include "../bd.php";
$bdd = getBD();
$id_art = isset($_GET['id_art']) ? $_GET['id_art'] : null;

if ($id_art) {
    $query = $bdd->prepare('SELECT * FROM Article WHERE id_art = :id_art');
    $query->bindParam(':id_art', $id_art, PDO::PARAM_INT);
    $query->execute();
    $row = $query->fetch(PDO::FETCH_ASSOC);
}

if ($row) {
    $id_art = $row['id_art'];
    $nom = $row['nom'];
    $quantite = $row['quantite'];
    $prix = $row['prix'];
    $url_photo = $row['url_photo'];
    $description = $row['description'];
    $lines = explode("\n", $description);


    $quantite_max = $quantite;

    session_start();
    if (isset($_SESSION['client'])) {
        $client_id = $_SESSION['client']['id_client'];
        $panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : array();
        
        foreach ($panier as $article) {
            if ($article['id_art'] == $id_art) {
                
                $quantite_panier = $article['quantite'];
                $quantite_max = min($quantite_max, $quantite - $quantite_panier);
            }
        }

        if (isset($_SESSION['quantite_max'][$id_art])) {
            $quantite_max = min($quantite_max, $_SESSION['quantite_max'][$id_art]);
        }

        if (isset($_POST['quantite_article'])) {
            $quantite_choisie = (int)$_POST['quantite_article'];
            if ($quantite_choisie > 0 && $quantite_choisie <= $quantite_max) {
                $_SESSION['quantite_max'][$id_art] = $quantite_choisie;
                $quantite_max = $quantite_choisie;
            }
        }
    }
?>
    <h1><?php echo $nom; ?></h1>
    <div class="card-container">
        <img src="<?php echo '../' . $url_photo; ?>" alt="Image de <?php echo $nom; ?>" class="card-image">
        <ul class="card-detail">
            <?php for ($i = 0; $i < 4 && $i < count($lines); $i++) {
                echo "<li>" . $lines[$i] . "</li>";
            } ?>
        </ul>
    </div>
    <?php
    if (isset($_SESSION['client'])) {
    ?>
    <form action="../ajouter.php" method="POST">
        <input type="hidden" name="id_art" value="<?php echo $id_art; ?>">
        
        <input type="number" name="quantite_article" placeholder="Quantité" min="0" max="<?php echo $quantite_max; ?>" value="1">
        <input type="submit" value="Ajouter l'article">
    </form>
    <?php
    }
    ?>
    <div class="card-price">
        <p class="price"><?php echo $prix; ?> ¥</p>
    </div>
<?php
} else {
    echo "Article introuvable...";
}
?>
<a href="../index.php"><div class="return"> Retour </div></a>
</body>
</html>
