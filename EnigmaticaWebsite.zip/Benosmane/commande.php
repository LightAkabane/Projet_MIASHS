<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
</head>
<body>    
    <?php
    session_start();

    if (isset($_SESSION['client'])) {
        require("bd.php");
        $bdd = getBD();

        $query = "SELECT nom, prix FROM Article WHERE id_art = :id_art";
        $stmt = $bdd->prepare($query);
        $stmt->bindParam(':id_art', $id_art, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        $panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : array();
        $client = $_SESSION['client'];
        if (!empty($panier)) {
            echo '<h1> Recapitulatif de votre commande</h1>';
            echo '<table border="1">';
            echo '<tr><th>ID Article</th><th>Nom</th><th>Quantité</th></tr>';

            $montant_total = 0; 

            foreach ($panier as $article) {
                $id_art = $article['id_art'];
                $quantite = $article['quantite'];

              
                $query = "SELECT nom, prix FROM Article WHERE id_art = :id_art";
                $stmt = $bdd->prepare($query);
                $stmt->bindParam(':id_art', $id_art, PDO::PARAM_INT);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    $nom = $row['nom'];
                    $prix_unitaire = $row['prix'];
                    
                    
                    $prix_total = $prix_unitaire * $quantite;
                    $montant_total += $prix_total; 
                    
                    echo "<tr>";
                    echo "<td>$id_art</td>";
                    echo "<td>$nom</td>";
                    echo "<td>$quantite</td>";
                    echo "</tr>";
                }
            }

            echo '</table>';

            echo '<p>Montant de votre commande : ' . $montant_total . ' ¥</p>';

            echo '<p>La commande sera expédiée à l’adresse suivante :</p>';
            echo '<p>' . $client['nom'] . ' ' . $client['prenom'] . '</p>';
            echo '<p>' . $client['adresse'] . '</p>';
            ?>
            
            <form action="acheter.php" method="post">
    <button type="submit">Valider</button>
</form>
            <?php 
        } else {
            echo 'Votre panier est vide.';
        }
    } else {
        echo 'Vous devez être connecté pour accéder au panier.';
    }
    ?>
<a href="panier.php"><div class="return"> Retour </div></a>
</body>
</html>
