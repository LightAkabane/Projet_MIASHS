<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
</head>

<body>
    <h1>Formulaire d'inscription</h1>
<div class="formulaire">

<form method="post" action="enregistrement.php" autocomplete="on">

    <label for="n"> Nom : </label>
    <input type="text" id="n" name="n" value = <?php echo isset($_GET['n']) ?$_GET['n']:'';?>><br>

    <label for="p"> Prenom : </label>
    <input type="text" id="p" name="p"  value = <?php echo isset($_GET['p']) ?$_GET['p']:''; ?>><br>

    <label for="adr"> Adresse : </label>
    <input type="text" id="adr" name="adr"  value = <?php echo isset($_GET['adr']) ?$_GET['adr']:'';?>><br>

    <label for="num"> Numero de telephone : </label>
    <input type="text" id="num" name="num"  value =<?php echo isset($_GET['num']) ?$_GET['num']:'';?> ><br>

    <label for="mail"> Email : </label>
    <input type="text" id="mail" name="mail"  value =<?php echo isset($_GET['mail']) ?$_GET['mail']:'';?> ><br>

    <label for="mdp1"> Mot de passe : </label>
    <input type="password" id="mdp1" name="mdp1" ><br>

    <label for="mdp2"> Confirmez votre mot de passe : </label>
    <input type="password" id="mdp2" name="mdp2" ><br>

    <input type="submit" value="S'inscrire"><br>

</form>
</div>
</body>
</html>
