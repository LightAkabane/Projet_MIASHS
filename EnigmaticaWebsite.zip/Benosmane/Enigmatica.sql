-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : jeu. 26 oct. 2023 à 12:33
-- Version du serveur : 5.7.39
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `Enigmatica`
--

-- --------------------------------------------------------

--
-- Structure de la table `Article`
--

CREATE TABLE `Article` (
  `id_art` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix` float NOT NULL,
  `url_photo` varchar(200) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Article`
--

INSERT INTO `Article` (`id_art`, `nom`, `quantite`, `prix`, `url_photo`, `description`) VALUES
(1000012, 'Rizuna An', 19, 17.5, 'images/IMG_1947.jpg', 'Nom : Rizuna An\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique en PVC\r\nTirage photographique : Laminé '),
(1000116, 'Shuntaro Chishiya', 72, 17.8, 'images/IMG_1944.jpg', 'Nom : Shuntaro Chishiya\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique  en PVC\r\nTirage photographique : Laminé\r\n'),
(1000134, 'Hikari Kuina', 27, 14.5, 'images/IMG_1946.jpg', 'Nom : Hikari Kuina\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique en PVC\r\nTirage photographique : Laminé '),
(1000198, 'Yuzuha Usaghi', 14, 14.5, 'images/IMG_1943.jpg', 'Nom :Yuzuha Usaghi\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique  en PVC\r\nTirage photographique : Laminé\r\n'),
(1000245, 'Ryohei Arisu', 18, 22.5, 'images/IMG_1945.jpg', 'Nom : Ryohei Arisu\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique en PVC\r\nTirage photographique : Laminé ');

-- --------------------------------------------------------

--
-- Structure de la table `Clients`
--

CREATE TABLE `Clients` (
  `id_client` int(11) NOT NULL,
  `nom` varchar(1000) NOT NULL,
  `prenom` varchar(1000) NOT NULL,
  `adresse` text NOT NULL,
  `numero` int(11) NOT NULL,
  `mail` varchar(1000) NOT NULL,
  `mdp` varchar(5000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Clients`
--

INSERT INTO `Clients` (`id_client`, `nom`, `prenom`, `adresse`, `numero`, `mail`, `mdp`) VALUES
(1, 'Shuntaro', 'Chishiya', '189 Gare de Shibuya', 727312827, 'shuntaro.chishiya@mail.jp', '$2y$10$nrzBt/A5okYun7UYN04IEOyY3Ez3J2sATgRPnQGG9W07DuI.vRX4u'),
(2, 'Yuzuha', 'Usaghi', '123 rue du Mont-Tao', 728391837, 'yuzuha.usaghi@mail.jp', '$2y$10$oZMO03RHWrUbKQ/J6bPXCe4ASrAsBwlzd1/u74uArtJq874Be1..y'),
(5, 'Akabane', 'Light', '99 Avenue du Borderland', 667991213, 'light.akabane@mail.jp', '$2y$10$mGo7dToyxhrNMw1LZ5zk4uyYstcPSw6o6sidSNWppZwga4GlAVYUq'),
(6, 'Benos', 'Hich\' Hich\'', 'Rue Victor Hugo la récitation', 707070707, 'miam@wow.fr', '$2y$10$uBn0yLACjc3NY904LOvz2.j3BChda3EHWfs4nUeu2thKv3l9HsUhu');

-- --------------------------------------------------------

--
-- Structure de la table `Commande`
--

CREATE TABLE `Commande` (
  `id_commande` int(11) NOT NULL,
  `id_art` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `envoi` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Commande`
--

INSERT INTO `Commande` (`id_commande`, `id_art`, `id_client`, `quantite`, `envoi`) VALUES
(2, 1000116, 5, 4, 0),
(3, 1000134, 5, 2, 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Article`
--
ALTER TABLE `Article`
  ADD PRIMARY KEY (`id_art`);

--
-- Index pour la table `Clients`
--
ALTER TABLE `Clients`
  ADD PRIMARY KEY (`id_client`);

--
-- Index pour la table `Commande`
--
ALTER TABLE `Commande`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `id_art` (`id_art`),
  ADD KEY `id_client` (`id_client`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Clients`
--
ALTER TABLE `Clients`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `Commande`
--
ALTER TABLE `Commande`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Commande`
--
ALTER TABLE `Commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `Clients` (`id_client`),
  ADD CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`id_art`) REFERENCES `Article` (`id_art`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
