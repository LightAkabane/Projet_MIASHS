<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <?php
require("bd.php");

function enregistrer($nom, $prenom, $adresse, $numero, $mail, $mdp1) {
    try {
        $bdd = getBD();
        $mdp_hash = password_hash($mdp1, PASSWORD_DEFAULT);
        $query = "INSERT INTO Clients(nom,prenom,adresse,numero,mail,mdp) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $bdd->prepare($query);
        $stmt->execute([$nom, $prenom, $adresse, $numero, $mail, $mdp_hash]);
        echo "toto";
        $bdd = null;
    } catch (PDOException $e) {
        echo "Erreur dans l'enregistrement : " . $e->getMessage();
    }
}

$nom = isset($_POST['n']) ? $_POST['n'] : '';
$prenom = isset($_POST['p']) ? $_POST['p'] : '';
$adresse = isset($_POST['adr']) ? $_POST['adr'] : '';
$numero = isset($_POST['num']) ? $_POST['num'] : '';
$mail = isset($_POST['mail']) ? $_POST['mail'] : '';
$mdp1 = isset($_POST['mdp1']) ? $_POST['mdp1'] : '';
$mdp2 = isset($_POST['mdp2']) ? $_POST['mdp2'] : '';

if (empty($nom) || empty($prenom) || empty($adresse) || empty($numero) || empty($mail) || empty($mdp1) || empty($mdp2) || $mdp1 !== $mdp2) {
    $url = 'nouveau.php?n=' . urlencode($nom) . '&p=' . urlencode($prenom) . '&adr=' . urlencode($adresse) . '&num=' . urlencode($numero);
    echo '<meta http-equiv="refresh" content="0; URL=' . $url . '">';
} else {
    enregistrer($nom, $prenom, $adresse, $numero, $mail, $mdp1);
    echo '<meta http-equiv="refresh" content="0; URL=index.php">';
}
?>

</head>

<body>
<div class="citation">Vérification des informations ...</div>
</body>
</html>
