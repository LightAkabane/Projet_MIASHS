<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
</head>
<body>
    <?php
    session_start();

    if (isset($_SESSION['client'])) {
        require("bd.php");
        $bdd = getBD();

    
        $panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : array();

        if (!empty($panier)) {
            echo '<h1>Votre Panier</h1>';
            echo '<table border="1">';
            echo '<tr><th>ID Article</th><th>Nom</th><th>Prix unitaire</th><th>Quantité</th><th>Prix total</th></tr>';

            $montant_total = 0; 

            foreach ($panier as $article) {
                $id_art = $article['id_art'];
                $quantite = $article['quantite'];

              
                $query = "SELECT nom, prix FROM Article WHERE id_art = :id_art";
                $stmt = $bdd->prepare($query);
                $stmt->bindParam(':id_art', $id_art, PDO::PARAM_INT);
                $stmt->execute();
                $row = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($row) {
                    $nom = $row['nom'];
                    $prix_unitaire = $row['prix'];
                    
                    
                    $prix_total = $prix_unitaire * $quantite;
                    $montant_total += $prix_total; 
                    
                    echo "<tr>";
                    echo "<td>$id_art</td>";
                    echo "<td>$nom</td>";
                    echo "<td>$prix_unitaire ¥</td>";
                    echo "<td>$quantite</td>";
                    echo "<td>$prix_total ¥</td>";
                    echo "</tr>";
                }
            }

            echo '</table>';

        
            ?>
            <div class="declamontant" > <?php echo 'Montant total de la commande : ' . $montant_total . ' ¥'?></div>
            <a href="commande.php"><button>Passer votre commande</button></a>
            <?php 
        } else {
            echo 'Votre panier est vide.';
        }
    } else {
        echo 'Vous devez être connecté pour accéder au panier.';
    }
    ?>
<a href="index.php"><div class="return"> Retour </div></a>
</body>
</html>
