<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
</head>
<body>
<div class="citation">Vérification des informations ...</div>
<?php
require("bd.php");

$mailc = isset($_POST['mail']) ? $_POST['mail'] : '';
$mdp1c = isset($_POST['mdp1']) ? $_POST['mdp1'] : '';

$bdd = getBD();

session_start();
if (!empty($_POST['csrf_token']) && hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    $query = "SELECT * FROM Clients WHERE mail = :mail";
    $stmt = $bdd->prepare($query);
    $stmt->bindParam(':mail', $mailc);
    $stmt->execute();
    $row = $stmt->fetch();

    if ($row) {
        $mdp_hache = $row['mdp'];
        if (password_verify($mdp1c, $mdp_hache)) {
            $_SESSION['client'] = array(
                'id_client' => $row['id_client'],
                'nom' => $row['nom'],
                'prenom' => $row['prenom'],
                'adresse' => $row['adresse'],
                'numero' => $row['numero'],
                'mail' => $row['mail']
            );
            header('Location: index.php');
            exit();
        }
    }
} else {

    echo "Erreur de vérification CSRF. Rechargez la page et réessayez.";
}

header('Location: connexion.php');
exit();
?>
</body>
</html>
