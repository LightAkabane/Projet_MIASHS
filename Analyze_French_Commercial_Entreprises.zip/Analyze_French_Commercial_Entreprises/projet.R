fichier <- read.csv("Fichier_final.csv",sep=";")

moyennes_ca <- rowMeans(fichier[, c("ca_1", "ca_2", "ca_3")], na.rm = TRUE)
fichier <- cbind(fichier, Moyenne_CA = moyennes_ca)

library(dplyr)

stats_moyennes_ca_1 <- tibble(
  Moyenne = mean(fichier$ca_1, na.rm = TRUE),
  Median = median(fichier$ca_1, na.rm = TRUE),
  Q1 = quantile(fichier$ca_1, probs = 0.25, na.rm = TRUE),
  Q3 = quantile(fichier$ca_1, probs = 0.75, na.rm = TRUE),
  Ecart_type = sd(fichier$ca_1, na.rm = TRUE),
  Etendue = range(fichier$ca_1, na.rm = TRUE),
  Ecart_interquartile = IQR(fichier$ca_1, na.rm = TRUE))


stats_moyennes_ca_1 <- stats_moyennes_ca_1 %>% slice(-1)

stats_moyennes_ca_2 <- tibble(
  Moyenne = mean(fichier$ca_2, na.rm = TRUE),
  Median = median(fichier$ca_2, na.rm = TRUE),
  Q1 = quantile(fichier$ca_2, probs = 0.25, na.rm = TRUE),
  Q3 = quantile(fichier$ca_2, probs = 0.75, na.rm = TRUE),
  Ecart_type = sd(fichier$ca_2, na.rm = TRUE),
  Etendue = range(fichier$ca_2, na.rm = TRUE),
  Ecart_interquartile = IQR(fichier$ca_2, na.rm = TRUE)
)
stats_moyennes_ca_2 <- stats_moyennes_ca_2 %>% slice(-1)

stats_moyennes_ca_3 <- tibble(
  Moyenne = mean(fichier$ca_3, na.rm = TRUE),
  Median = median(fichier$ca_3, na.rm = TRUE),
  Q1 = quantile(fichier$ca_3, probs = 0.25, na.rm = TRUE),
  Q3 = quantile(fichier$ca_3, probs = 0.75, na.rm = TRUE),
  Ecart_type = sd(fichier$ca_3, na.rm = TRUE),
  Etendue = range(fichier$ca_3, na.rm = TRUE),
  Ecart_interquartile = IQR(fichier$ca_3, na.rm = TRUE)
)

stats_moyennes_ca_3 <- stats_moyennes_ca_3 %>% slice(-1)

moyenne1<-mean(fichier$ca_1,na.rm=TRUE)
moyenne2<-mean(fichier$ca_2,na.rm=TRUE)
moyenne3<-mean(fichier$ca_3,na.rm=TRUE)

plot(c(2020,2021,2022),c(moyenne3,moyenne2,moyenne1),type='b',main="Moyenne au cours des 3 dernières années",xlab = "année",ylab="moyenne du chiffre d'affaire",col="black")

CAPAP1<- aggregate(fichier$ca_1 ~ fichier$code_ape, data = fichier , FUN = mean)

CAPAP2<- aggregate(fichier$ca_2 ~ fichier$code_ape, data = fichier , FUN = mean)

CAPAP3<- aggregate(fichier$ca_3 ~ fichier$code_ape, data = fichier , FUN = mean)

CAPAPost1<- aggregate(fichier$ca_1 ~ fichier$code_départementaux, data = fichier , FUN = mean)

CAPAPost2<- aggregate(fichier$ca_2 ~ fichier$code_départementaux, data = fichier , FUN = mean)

CAPAPost3<- aggregate(fichier$ca_3 ~ fichier$code_départementaux, data = fichier , FUN = mean)

vertical_theme <- function(base_size = 9, base_family = "") {
  theme_minimal(base_size = base_size, base_family = base_family) +
    theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1),
          axis.title.x=element_blank(),
          axis.text.y = element_text(size = rel(0.7)),
          plot.title = element_text(size = rel(1.2)))
}

ggplot(CAPAP1, aes(x = `fichier$code_ape`, y = `fichier$ca_1`)) +
  geom_bar(stat = "identity", fill = "#69b3a2") +
  labs(y = "Moyenne de CA", title = "Moyennes du chiffre d'affaire de 2022 par code APE") +
  vertical_theme()


ggplot(CAPAP2, aes(x = `fichier$code_ape`, y = `fichier$ca_2`)) +
  geom_bar(stat = "identity", fill = "#69b3a2") +
  labs(y = "Moyenne de CA", title = "Moyennes de chiffre d'affaire de 2021 par code APE") +
  vertical_theme()


ggplot(CAPAP3, aes(x = `fichier$code_ape`, y = `fichier$ca_3`)) +
  geom_bar(stat = "identity", fill = "#69b3a2") +
  labs(y = "Moyenne de CA", title = "Moyennes de chiffre d'affaire de 2020 par code APE") +
  vertical_theme()

AnovaCA1PA<- aov( ca_1~code_départementaux, data = fichier)
summary(AnovaCA1PA)
AnovaCA2PA<- aov( ca_2~ code_départementaux, data = fichier)
summary(AnovaCA2PA)
AnovaCA3PA<- aov( ca_3~ code_départementaux, data = fichier)
summary(AnovaCA3PA)

library(ggplot2)
library(maps)
library(dplyr)
data2 <- read.csv("heatmap2.csv",sep =";" )

france <- map_data("france")


france_data2 <- left_join(france, data2, by = c("region" = "Departement"))
ggplot(france_data2, aes(x = long, y = lat, group = group, fill = ca_2)) +
  geom_polygon() +
  scale_fill_gradient(low ="lightblue", high = "blue") +
  coord_equal() +
  theme_void()
