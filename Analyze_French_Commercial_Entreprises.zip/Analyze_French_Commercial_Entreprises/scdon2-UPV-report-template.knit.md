---
title: "Rapport de groupe en Sciences des Données 2 + Bases de données"
author:
- 'Benosmane Yacine, '
- ' Benmouloud Mehdi,'
- ' Lassouani Mohamed-Yacine'
- ' Mouanou Mitori Guichel'
date: "07/05/2023"
output:
  pdf_document:
    fig_caption: yes
    keep_md: yes
    keep_tex: yes
    md_extensions: +raw_attribute
    number_sections: yes
    pandoc_args:
    - --top-level-division="chapter"
    - --bibliography="references.bib"
    template: template.tex
    toc: yes
  html_document:
    df_print: paged
    toc: yes
    toc_depth: '2'
  word_document:
    fig_caption: yes
    number_sections: yes
    pandoc_args: 
    - --top-level-division="chapter"
    - --to="odt+native_numbering"
    toc: yes
    toc_depth: '1'
toc-title: "Table des matières"
bibliography: references.bib
coursecode: TV15MI-TV25MI
csl: iso690-author-date-fr-no-abstract.csl
Acknowledgements:
- Nos plus sincères remerciements vont à notre encadrant pédagogique pour les conseils
  avisés sur notre travail.
biblio-style: elsarticle-harv
session: 2022
team: XXX
always_allow_html: true
---


# Introduction {.label:s-intro}

Investir dans le secteur des entreprises a toujours été un sujet d'intérêt pour les investisseurs. Les opportunités d'investissement dans l'industrie vont de l'achat de participations dans de grandes chaînes à l'investissement direct dans des startups.

Cependant, avec la récente perturbation économique causée par la pandémie de COVID-19, beaucoup se demandent si investir dans le secteur des entreprises sera toujours rentable en 2023. Alors que certains secteurs d'activité ont été durement touchés par la pandémie, d'autres ont connu une croissance importante en raison de l'augmentation des achats en ligne et de la demande accrue pour certains produits.

Dans ce projet , nous examinons les tendances actuelles du marché, les opportunités d'investissement dans le secteur des entreprises, ainsi que les risques et les défis qui y sont associés.

Nous évaluerons également si investir dans le secteur commercial peut être considéré comme rentable en 2023 et s'il s'agit d'un bon choix pour les investisseurs à la recherche de rendements attractifs.


\bigskip

**Est-t-il intéressant d'investir dans le secteur commercial pour l'année 2023 ?**

\bigskip

# Base de donnée

## Descriptif des tables 

| Nom colonne | Type | Signification 
|:-----------:|:----:|:-------------:
|Id_Indicateur|int(11)|Identifiant de l'entreprise
| Millesime_1(2,3) | year(4)|Année du bilan financier
|Date_cloture_1(2,3)|date|Date de clôture d'exercice
|Chiffre_d'affaire_1(2,3)|bigint(11)| Chiffre d'affaire réalisé 
|Resultat_1(2,3)|bigint(11)|Resultat net de l'entreprise 
|tranche_CA_millesime_1(2,3)|varchar(20)| Tranche de chiffre d'affaire

\medskip

Table: INDICATEUR (3561L $\times$ 16C)

Cette table permettra d'évaluer la performance financière d'une entreprise sur plusieurs années afin de nous aider à prendre des décisions d'investissement dans le secteur commercial

\medskip

| Nom colonne | Type | Signification 
|:-----------:|:----:|:-------------:
|code_ape|varchar(5)|Code activité principale exercé
| Description | varchar(84)|Description de l'activité principale

Table: ACTIVITE (83L $\times$ 2C)

Cette table permet de spécialiser l'activité principale de l'entreprise.

\medskip

| Nom colonne | Type | Signification 
|:-----------:|:----:|:-------------:
|Numero_Siren|int(14)|Identifiant d'entreprise
|Denomination| varchar(1000)|Nom de l'entreprise
|ID_Region|int(5)|Identifiant de la région
|Debut_activite|date|Date de début d'activité
|Activite_principale|varchar(20)| Code APE

Table: ENTREPRISE (3561L $\times$ 5C)

Les différentes informations sur les entreprises permettront de prendre des décisions d'investissement au sein de ce secteur.

\medskip

| Nom colonne | Type | Signification 
|:-----------:|:----:|:-------------:
|ID_Région|int(5)|Identifiant de la région
|Ville| varchar(32)|Nom de la région

Table: REGIONS (1725L $\times$ 2C)

\bigskip
## Modèles MCD et MOD
\begin{figure}[h]
  \begin{minipage}[t]{0.48\textwidth}
    \centering
    \includegraphics[width=0.8\linewidth]{MCD.png}
    \caption{MCD}
    \label{fig:MCD}
  \end{minipage}
  \hfill
  \begin{minipage}[t]{0.48\textwidth}
    \centering
    \includegraphics[width=0.8\linewidth]{MOD.png}
    \caption{MOD}
    \label{fig:MOD}
  \end{minipage}
\end{figure}

## Import des données 

### Prétraitement des données :
Le prétraitement des données est une étape importante dans l'obtention de données de qualité dans un but analytique. 

Tout d'abord plusieurs colonnes inutiles ont été retiré des données concernant l'ensemble des entreprises françaises car elles n'étaient pas assez pertinentes dans notre analyse. 
Il y a les données suivante:  
- NIC,Forme juridique, Adresse, Numéro de département, Numéro de région, Code greffe, Appelation du code greffe ,Date de radiation,Statut,Géolocalisation,3 durées d'activité des 3 dernières années , 3 effectifs des 3 dernières années, Fiche identité 

Ensuite, nous avons filtré les données de la colonne libellé pour prendre uniquement les entreprises du secteur commercial. Cela nous a permis de nous concentrer sur le domaine de notre étude

Nous avons également filtré les données des colonnes des chiffres d'affaire 1, chiffre d'affaire 2 et chiffre d'affaire 3 afin de retirer toutes les données qui ne contenaient pas ces informations. Ainsi, nous avons pu nous assurer que les données sur les chiffres d'affaires étaient complètes.

Nous avons par la suite extrait les colonnes code postal et ville pour les mettre dans un autre fichier CSV car ces informations concernaient une autre table de données 

Enfin, nous avons extrait tous les codes APE et les avons reliés à un fichier CSV externe contenant l'ensemble des codes APE relié à leurs dénominations propre. Cette étape nous a permis d'avoir une meilleure compréhension des activités des entreprises analysées.

En somme, le prétraitement des données est une étape cruciale pour obtenir des données de qualité avant de les analyser. Les modifications apportées au fichier CSV "Chiffre clés" ont permis de s'assurer que les données étaient pertinentes et complètes, et ont ainsi facilité l'importation des données.

\bigskip

## Requêtes réalisées
\bigskip
1) On souhaite afficher le nombre d'entreprise ayant un résultat moyent positif au cours des 3 dernières années . (2978 entreprises)

```rmysql
SELECT*
FROM entreprise, INDICATEUR
WHERE
ENTREPRISE.Numero_Siren=INDICATEUR.ID_Indicateur
AND ( resultat_1+resultat_2+resultat_3)/3 >0; 
```
\bigskip
2) On souhaite afficher le résultat maximal au cours des 3 dernières années 
On obtient:
( resultat_max_1 = 423461219 | resultat_max_2 = -124621133 | resultat_max_3 = 3708236783)

```rmysql
SELECT MAX(i.resultat_1) AS resultat_max_1, MIN(i.resultat_2) AS resultat_max_2, MAX(i.resultat_3) AS resultat_max_3
FROM indicateur i;
```
\bigskip
3) Affichage de la moyenne des chiffres d'affaires au cours des 3 dernières années.

\bigskip

```rmysql
SELECT AVG(CA_total) AS moyenne_CA_total
FROM (
SELECT SUM(Chiffre_affaire_1 + Chiffre_affaire_2 + Chiffre_affaire_3) AS CA_total
FROM INDICATEUR
GROUP BY ID_indicateur
) AS CA_total_entreprises; `
```
\bigskip
4) Affichage des entreprises d'un domaine (ex : véhicule) ayant un résultat croissant au cours des trois dernières années. ( 2 entreprises )
\bigskip

```rmysql
SELECT DISTINCT des.ACT_DES,des.ACT_CODE
FROM(SELECT ACTIVITE.Description as ACT_DES,ACTIVITE.code_ape as ACT_CODE
FROM ENTREPRISE
INNER JOIN INDICATEUR
   ON ENTREPRISE.Numero_Siren=INDICATEUR.ID_Indicateur
INNER JOIN ACTIVITE
   ON ENTREPRISE.Activite_Principale=ACTIVITE.code_ape
INNER JOIN REGION
   ON ENTREPRISE.ID_Région=REGION.code_postal
WHERE INDICATEUR.Resultat_1<INDICATEUR.Resultat_2 AND INDICATEUR.Resultat_2<INDICATEUR.Resultat_3) AS des
WHERE des.ACT_DES LIKE '%vehicule%';
```
\bigskip
# Analyse statistique des Données
\bigskip
La pandémie de Covid-19 a bouleversé de nombreux secteurs de l'économie mondiale et le secteur commercial n'a pas été épargné, les conséquences de cette dernières ont entraîné des changements dans les comportements d'achat des consommateurs ainsi que des perturbations dans les chaînes d'approvisionnement pour l'obtention des marchandises. Dans ce contexte, l'analyse statistique des données peut jouer un rôle crucial dans l'identification des enteprises les plus résilientes et les plus prometteuses pour l'investissement. En utilisant les outils que R nous met a disposition, nous pourrons d'une part analyser et comparer les performances financières pré et post-pandémie des entreprises pour comprendre les différences et les tendances émergentes. D'autre part nous pourrons examiner les chiffres clés des entreprises par le biais des indices statistiques pour chaque année.En combinant ces analyses, nous pourrons fournir des infomations pour orienter les décisions d'investissement dans le secteur commercial. 

## Description de la situation statistique

La situation statistique présente comme population des entreprises du secteurs commercial,et possède chacuns 4 variables qualitative nominal qui sont leur "Nom", leur "département, leur "Activité principale" et leur "code siren". Aussi, elle possède des variables quantitative discrète qui sont chiffre d'affaire 1,2 et 3 correspondant aux 3 dernières années, ainsi que le résultats 1,2 et 3 correspondant aux 3 dernières années.Ces données étaient présenté sous le format d'un fichier csv répertoriant l'ensemble des entreprises se situant en France   

## Analyse spécifique des résultats des entreprises 
Dans le but de pouvoir mener à bien notre étude nous avons décidé de faire l’études descriptif de notre population  il s’agit entre autre de déterminer les indicateurs comme la moyenne,médiane,etc… et ensuite donner une interprétation. Nous allons donc étudier les résultats en fonction des 3 dernières années



 En prémier lieu nous allons comparer les moyennes:
 Moyenne1

```
## [1] 705557.6
```
Moyenne 2

```
## [1] 385546.7
```
Moyenne3

```
## [1] 1070420
```

On observe que la moyenne de l'année 2020 étant égale à 1069857 est largement surperieur à celle de 2022 et 2020.

Le diagramme cirulaire ci-dessous reprensente en pourcentage les differents moyennes 


\includegraphics[width=0.5\linewidth]{scdon2-UPV-report-template_files/figure-latex/unnamed-chunk-9-1} 
\n
Ensuite on calcule les quantiles de chacune des années. 

Les quantiles de 2020


```
##    25%    50%    75% 
##   1112  24912 102610
```

```
## [1] 101498
```
 L'ecart interquantile étant très élévé(101502.5 )Par rapport à ce resultat on peut affirme qu'on a une grande dispertion au seins de cette population
 
 Les quantiles de 2021


```
##      25%      50%      75% 
##   6989.5  40177.0 132540.5
```

```
## [1] 125551
```
 L'ecart interquantile étant  élévé(125534 ) Par rapport à ce resultat on peut dire qu'on a une grande dispertion au seins de cette population
 
 Les quantiles de 2022


```
##      25%      50%      75% 
##   4341.5  42706.5 176975.2
```

```
## [1] 172633.8
```
 L'ecart interquantile étant très élévé(172652.5 ) Par rapport à ce resultat on peut dire qu'on a une grande dispertion au seins de cette population
 
 En troisième lieu il y a les écartypes
 
Année 2020
 

```
## [1] 1.232102e+14
```

```
## [1] "ecart type de resultat1"
```

```
## [1] 11100007
```
 Au vu des résultats, l' ecart type est tres grande dons on a une grande dispersion autour de moyenne 

 Année 2021
 

```
## [1] 4.048048e+13
```

```
## [1] "ecart type de resultat2"
```

```
## [1] 6362428
```
 Certes la dispersion est grande en 2020 mais elle ne l'es pas autant qu'en 2021 cela est causé par la covid qui a mis tout le monde à terre
 
 
 Année 2022
 

```
## [1] 4.074842e+15
```

```
## [1] "ecart type de resultat2"
```

```
## [1] 63834493
```
 Là aussi la dispersion est grande est lègerement plus élévé qu'en 2021 cela s'explique par la relance économique après covid 
 
 Ci contre, se présente les distributions pour chacunes des années

\includegraphics[width=0.5\linewidth]{scdon2-UPV-report-template_files/figure-latex/unnamed-chunk-16-1} 
  
  A travers ces trois graphes on a donc une conclusion 2020 qui est supérieur en terme de résultat et malgré la crise de 2021 on a une croissance en 2022
  
\bigskip

Nous allons dorénavant étudier la relation entre les résultats et l'activité principale sur les trois dernières années. On obtient les graphiques suivant:

\medskip
| ![2020.](2020.png){#2020 width="3cm" height="4cm"} | ![2021.](2021.png){#2021 width="3cm" height="4cm"} | ![MC2.](2022.png){#2022 width="3cm" height="4cm"} |

Ces graphiques nous permette de conclure que l'activité des commerces surgelés prédomine le marché en therme de résultats. Nous allons donc proceder à un test de l'anova sur les trois années afin de déterminer si l'activité principale influe sur le résultat. 

- ![anova_2020.](anov2020.png){#MCD width="8cm" height="4cm"}
- ![anova_2021.](anov2021.png){#MCD width="8cm" height="4cm"}
- ![anova_2022.](anov2022.png){#MCD width="8cm" height="4cm"}

Les résultats de l'analyse ANOVA ont montré que la valeur p associée au facteur "code_ape" était supérieure à la valeur seuil de 0,05 (p>0,05), 
montrant qu'il n'y avait pas de différence significative entre la moyenne des groupes déterminée par ce facteur. La somme des carrés de la variation résiduelle est élevée,ce qui peut suggérer la présence d'autres facteurs influençant les variables analysées mais qui n'ont pas été pris en compte dans cette analyse

Nous allons donc procédé à l'analyse de la liaisons entre les résultats observé par entreprise selon la localité. Pour chaque année on obtient le même graphique ci contre (à quelques variance près)

- ![enel](enel.png){#MCD width="8cm" height="4cm"}

Nous observons que les hubs obtiennent les résultats les plus importants. Cela s'explique par la relance économique ainsi que la concentration d'entreprise proche entre elle ce qui réduit le prix d'importation.

## Analyse spécifique des chiffres d'affaires des entreprises 

De la même manière que précédemment, nous allons tenter d'étudier de manière la plus précise 
les tendances concernant les chiffres d'affaires de chacunes des entreprises. 

- ![resum.](resume.png){#MCD width="8cm" height="4cm"}


On peut remarquer une certaine évolution des recettes des entreprises  de manière importante, il est donc important de déterminer si l'activité principal est un facteur de cette expension.

Nous allons donc étudier graphiquement la moyenne du chiffre d'affaire selon l'activité principal

On obtient alors de manière uniforme le même graphique pour chaque année. En effet, tout comme l'analyse des résultats des entreprises, l'activité des commerces surgelés prédomine le marché.

- ![activ1.](activ1.png){#MCD width="8cm" height="4cm"}

Il est donc trivial de proceder à un test de l'anova sur les trois années afin de déterminer si l'activité principale influe sur le résultat. 

Notons que l'année 2021 montre que la F-value est de 2,385 et la p-value associée est de 9.18e-11, ce qui est inférieur au seuil de signification de 0,05. Cela suggère que les moyennes des groupes comparés sont significativement différentes, et donc que l'hypothèse nulle d'égalité des moyennes peut être rejetée.

Etudions dorénavant, le liens entre le chiffre d'affaire et la localité. Pour se faire, nous avons mis en place une heatmap à l'aide de RStudio. Certaines valeurs sont manquante et apparaisse en gris car ces informations sont manquantes dans la base de données initial

- ![heatmap.](heatmap.png){#MCD width="8cm" height="4cm"}

Remarquons que la moyenne du chiffre d'affaire selon la localité reste tout à fait homogène. Cependant, nous ne pouvons négliger que certaines zones comme Paris les Yvelines et Saine-Saints-Denis, possèdent une certaines densité de population qui pousse à la consommation ce qui explique cette écart de chiffre d'affaires avec les autres départements qui sont homogènes
\normalsize


# Conclusion et perspectives {.label:ccl}

A l'aide les analyses  effectuées précédemment on a remarques la COVID a eu une grande influence sur l'ensemble des activité de ces trois dernières années notamment en 2021 malgré cela ,Nous pensons donc que ce secteur va continuer à croître dans le futur. La localité ne nous a pas semblé être un facteur déterminant, même si avec d'autres données, nous aurions certainement pu prouver le contraire.
Le secteur commercial est donc un secteur prometteur. Cependant, malgré la profondeur de notre analyse, nous ne pouvons pas conclure que ce secteur sera à coup sûr rentable. Il nous faudrait d'autres indicateurs tels que le ROI, la rentabilité ou encore la profitabilité pour évaluer sa performance financière.


\bigskip

Lister également les difficultés rencontrées dans la partie BD (e.g., taille de la base, manque de données, ...) et dans la partie statistique.

# Bibliographie {-}

[CHIFFRE CLES](https://www.data.gouv.fr/fr/datasets/chiffres-cles-2022/)

[CODE AFE](https://public.opendatasoft.com/explore/dataset/nomenclature-dactivites-francaise-naf-rev-2/table/?flg=fr)

[CODE POSTAUX](https://www.data.gouv.fr/fr/datasets/communes-de-france-base-des-codes-postaux/)

 -Le logiciel R: Maîtriser le langage, effectuer des analyses (bio)statistiques Broché – 9 octobre 2014
  - Comprendre et réaliser les tests statistiques à l'aide de R: Manuel   de biostatistique Broché – Livre grand format, 30 janvier     2018
  -  SQL 2015

\bibliographystyle{elsarticle-harv}
\bibliography{references}


## **Codes** {-}

Ajouter vos codes informatique ici. Les codes doivent être correctement indentés et commentés.
