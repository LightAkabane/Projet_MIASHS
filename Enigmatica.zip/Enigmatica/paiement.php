<?php
session_start();
require_once('../vendor/autoload.php');
require_once('stripe.php');
if ($_SERVER['REQUEST_METHOD'] != 'POST') {
  echo 'Invalid request';
  exit;
}
$Commande = json_decode($_POST['commande'], true);
$checkout_session = $stripe->checkout->sessions->create([ 'customer' => $_SESSION['client']['id_stripe'] ,
'success_url' => 'http://localhost:8888/Benosmane/acheter.php',
'cancel_url' => 'http://localhost:8888/Benosmane/index.php',
'mode' => 'payment' ,
'automatic_tax' => ['enabled' => false], 'line_items' => $Commande,
]);
header("HTTP/1.1 303 See Other");
header("Location: " .  $checkout_session->url);
?>
