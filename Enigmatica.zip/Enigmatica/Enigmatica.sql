-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le : ven. 08 déc. 2023 à 21:21
-- Version du serveur : 5.7.39
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `Enigmatica`
--

-- --------------------------------------------------------

--
-- Structure de la table `Article`
--

CREATE TABLE `Article` (
  `id_art` int(11) NOT NULL,
  `nom` varchar(20) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix` float NOT NULL,
  `url_photo` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `ID_STRIPE` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Article`
--

INSERT INTO `Article` (`id_art`, `nom`, `quantite`, `prix`, `url_photo`, `description`, `ID_STRIPE`) VALUES
(1000012, 'Rizuna An', 700, 1750, 'images/IMG_1947.jpg', 'Nom : Rizuna An\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique en PVC\r\nTirage photographique : Laminé ', 'price_1OG2dpHLcgDBShHXlZJdrVzb'),
(1000116, 'Shuntaro Chishiya', 850, 1780, 'images/IMG_1944.jpg', 'Nom : Shuntaro Chishiya\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique  en PVC\r\nTirage photographique : Laminé\r\n', 'price_1OG2ehHLcgDBShHXpk74RJj3'),
(1000134, 'Hikari Kuina', 540, 1450, 'images/IMG_1946.jpg', 'Nom : Hikari Kuina\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique en PVC\r\nTirage photographique : Laminé ', 'price_1OG2fWHLcgDBShHXP4wumpR3'),
(1000198, 'Yuzuha Usaghi', 980, 1450, 'images/IMG_1943.jpg', 'Nom :Yuzuha Usaghi\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique  en PVC\r\nTirage photographique : Laminé\r\n', 'price_1OG2gpHLcgDBShHXjcoQ3NWz'),
(1000245, 'Ryohei Arisu', 970, 2250, 'images/IMG_1945.jpg', 'Nom : Ryohei Arisu\r\nTaille : 30cm x 15cm\r\nMatière : Fabrique en PVC\r\nTirage photographique : Laminé ', 'price_1OG2keHLcgDBShHX9v7yTnXe');

-- --------------------------------------------------------

--
-- Structure de la table `Clients`
--

CREATE TABLE `Clients` (
  `id_client` int(11) NOT NULL,
  `nom` varchar(1000) NOT NULL,
  `prenom` varchar(1000) NOT NULL,
  `adresse` text NOT NULL,
  `numero` int(11) NOT NULL,
  `mail` varchar(1000) NOT NULL,
  `mdp` varchar(5000) NOT NULL,
  `ID_STRIPE` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Clients`
--

INSERT INTO `Clients` (`id_client`, `nom`, `prenom`, `adresse`, `numero`, `mail`, `mdp`, `ID_STRIPE`) VALUES
(1, 'Shuntaro', 'Chishiya', '189 Gare de Shibuya', 727312827, 'shuntaro.chishiya@mail.jp', '$2y$10$nrzBt/A5okYun7UYN04IEOyY3Ez3J2sATgRPnQGG9W07DuI.vRX4u', 'cus_P4SaAtbwg9jLE6'),
(2, 'Yuzuha', 'Usaghi', '123 rue du Mont-Tao', 728391837, 'yuzuha.usaghi@mail.jp', '$2y$10$oZMO03RHWrUbKQ/J6bPXCe4ASrAsBwlzd1/u74uArtJq874Be1..y', 'cus_P4SbCLSnkHr10s'),
(5, 'Akabane', 'Light', '99 Avenue du Borderland', 667991213, 'light.akabane@mail.jp', '$2y$10$mGo7dToyxhrNMw1LZ5zk4uyYstcPSw6o6sidSNWppZwga4GlAVYUq', 'cus_P4B9u6IuqdIud7'),
(7, 'Benosmane', 'Yacine', '14 rue du leban ', 782888717, 'ya.benosmane@gmail.com', '$2y$10$Ky574S19HBnJ1F6qcrW7OeplP1jXB01XnvhTXAGBWH8GwsMOPCLHG', 'cus_P4Sc0cl8QyRS2X'),
(25, 'Belacel', 'Zyad', '11 impasse du Moulin', 237474, 'zyadbelacel@mail.jp', '$2y$10$EtLl/nVpcvMncoQhzZdScOIpwch4DJeg8Nocy6oG.n96Uqc0WJgFq', 'cus_P4ScejXxMzdTOW'),
(28, 'Kyle', 'Walker', 'Man', 987654367, 'kyle.walker@mail.uk', '$2y$10$6u9E0SRYLRc6o27ro9MdD.z2K7Lu.6uLnyI7/67Tsqof9dGC8W92O', 'cus_P6VrzVP3cNUGvy'),
(29, 'Lindemann', 'Maggie', '12 impasse Emile Accolas', 782888717, 'maggie.lindemann@mail.fr', '$2y$10$VYH8rFyklw84kmJcjOWML.yJUZkr3aO3Ns2HyUoMP.8oVf2Nm2ldW', 'cus_P6Vu3UCoHcQKp1'),
(33, 'Ntamack', 'Romain', 'Stade Toulousain', 1029384765, 'romain.ntamack@mail.fr', '$2y$10$y4pen.d9g0xtR8FQ1CwHku/BZq.wkHEJD2gHCYGssJ9QeyfGhFfOy', 'cus_P9TonFqrdGp1DW'),
(38, 'Islem', 'Slimani', 'Stade du 5 juillet', 1029384756, 'islem.slimani@mail.alg', '$2y$10$lbpVxAnoFPFhQtK5giXCBeUP8ITGqYvr5OEyOA.FwjyVcJfBTEIEq', 'cus_P9U08fshzcN6MC');

-- --------------------------------------------------------

--
-- Structure de la table `Commande`
--

CREATE TABLE `Commande` (
  `id_commande` int(11) NOT NULL,
  `id_art` int(11) NOT NULL,
  `id_client` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `envoi` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `Commande`
--

INSERT INTO `Commande` (`id_commande`, `id_art`, `id_client`, `quantite`, `envoi`) VALUES
(2, 1000116, 5, 4, 0),
(6, 1000012, 7, 1, 0),
(9, 1000245, 29, 1, 0),
(10, 1000134, 7, 1, 0),
(11, 1000134, 7, 1, 0),
(12, 1000134, 7, 1, 0),
(13, 1000134, 7, 1, 0),
(14, 1000012, 7, 1, 0),
(15, 1000012, 7, 1, 0),
(16, 1000012, 7, 4, 0),
(17, 1000012, 7, 5, 0),
(18, 1000012, 7, 10, 0),
(19, 1000012, 7, 10, 0),
(20, 1000116, 7, 20, 0);

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `user`, `content`, `timestamp`) VALUES
(4, 'Yacine', 'uwu', '2023-12-08 22:17:31'),
(5, 'Yacine', 'ça marhce', '2023-12-08 22:18:40');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `Article`
--
ALTER TABLE `Article`
  ADD PRIMARY KEY (`id_art`);

--
-- Index pour la table `Clients`
--
ALTER TABLE `Clients`
  ADD PRIMARY KEY (`id_client`),
  ADD KEY `ID_STRIPE` (`ID_STRIPE`);

--
-- Index pour la table `Commande`
--
ALTER TABLE `Commande`
  ADD PRIMARY KEY (`id_commande`),
  ADD KEY `id_art` (`id_art`),
  ADD KEY `id_client` (`id_client`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user` (`user`),
  ADD KEY `user_2` (`user`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `Clients`
--
ALTER TABLE `Clients`
  MODIFY `id_client` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT pour la table `Commande`
--
ALTER TABLE `Commande`
  MODIFY `id_commande` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `Commande`
--
ALTER TABLE `Commande`
  ADD CONSTRAINT `commande_ibfk_1` FOREIGN KEY (`id_client`) REFERENCES `Clients` (`id_client`),
  ADD CONSTRAINT `commande_ibfk_2` FOREIGN KEY (`id_art`) REFERENCES `Article` (`id_art`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
