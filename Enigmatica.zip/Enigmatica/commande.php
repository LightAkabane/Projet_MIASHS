<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
session_start();
require_once('vendor/autoload.php');
require_once('stripe.php');
if (isset($_SESSION['client'])) {
    require("bd.php");
    $bdd = getBD();
    $panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : array();
    $client = $_SESSION['client'];
    $id_client= $client['id_stripe'];

    if (!empty($panier)) {
        $montant_total = 0;
        $line_items = [];
        
        foreach ($panier as $article) {
            $id_art = $article['id_art'];
            $quantite = $article['quantite'];
        
            $query = "SELECT nom, prix, ID_STRIPE FROM Article WHERE id_art = :id_art";
            $stmt = $bdd->prepare($query);
            $stmt->bindParam(':id_art', $id_art, PDO::PARAM_INT);
            $stmt->execute();
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
            if ($row) {
                $nom = $row['nom'];
                $prix_unitaire = $row['prix'];
                $id_stripe = $row['ID_STRIPE'];
        
                $prix_total = $prix_unitaire * $quantite;
                $montant_total += $prix_total;
        
                $line_items[] = [
                    'price' => $id_stripe,
                    'quantity' => $quantite,
                ];
            }
        }
        $checkout_session = $stripe->checkout->sessions->create([ 'customer' => $_SESSION['client']['id_stripe'] ,
        'success_url' => 'http://localhost:8888/Benosmane/acheter.php',
        'cancel_url' => 'http://localhost:8888/Benosmane/index.php',
        'mode' => 'payment' ,
        'automatic_tax' => ['enabled' => false], 
        'line_items' => $line_items,
]);
        header('Location: ' . $checkout_session->url);
    } else {
        echo 'Votre panier est vide.';
    }
} else {
    echo 'Vous devez être connecté pour accéder au panier.';
}
?>

