<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Historique des Commandes</title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
    <link rel="shortcut icon" href="images/icon.ico" />
</head>
<body>

<?php
session_start();
if (isset($_SESSION['client'])) {
    require("bd.php");
    $bdd = getBD();
    $id_client = $_SESSION['client']['id_client'];

    $query = "SELECT C.id_commande, C.id_art, A.nom, A.prix, C.quantite, C.envoi FROM Commande C
              INNER JOIN Article A ON C.id_art = A.id_art
              WHERE C.id_client = :id_client";
    
    $stmt = $bdd->prepare($query);
    $stmt->bindParam(':id_client', $id_client, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "<h1>Historique des Commandes</h1>";
        echo "<table border='1'>";
        echo "<tr><th>ID Commande</th><th>ID Article</th><th>Nom de l'Article</th><th>Prix</th><th>Quantité Commandée</th><th>État de la Commande</th></tr>";

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "<tr>";
            echo "<td>" . $row['id_commande'] . "</td>";
            echo "<td>" . $row['id_art'] . "</td>";
            echo "<td>" . $row['nom'] . "</td>";
            echo "<td>" . $row['prix'] . " ¥</td>";
            echo "<td>" . $row['quantite'] . "</td>";
            echo "<td>" . ($row['envoi'] ? "Envoyée" : "Non envoyée") . "</td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "<div class='vide'>Aucune commande trouvée dans l'historique. </div>";
    }
} else {
    echo "Vous devez être connecté pour accéder à l'historique des commandes.";
}
?>
<br><br><br><br><br><br><br><br><br>

<button><a href="index.php">Retour</a></button>
<br>
</body>
</html>
