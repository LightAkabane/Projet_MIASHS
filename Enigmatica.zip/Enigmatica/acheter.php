<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
</head>
<body class="ici">
<?php
session_start();
if (isset($_SESSION['client'])) {
    require("bd.php");
    $bdd = getBD();
    $panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : array();

    if (!empty($panier)) {
        foreach ($panier as $article) {
            $id_art = $article['id_art'];
            $quantite = $article['quantite'];
            $id_client = $_SESSION['client']['id_client'];
            $query = "INSERT INTO Commande (id_art, id_client, quantite, envoi) VALUES (:id_art, :id_client, :quantite, false)";
            $stmt = $bdd->prepare($query);

            if (!$stmt) {
                echo "Erreur de préparation de la requête.";
            }

            $stmt->bindParam(':id_art', $id_art, PDO::PARAM_INT);
            $stmt->bindParam(':id_client', $id_client, PDO::PARAM_INT);
            $stmt->bindParam(':quantite', $quantite, PDO::PARAM_INT);

            if ($stmt->execute()) {
                $queryUpdateQuantite = "UPDATE Article SET quantite = quantite - :quantite WHERE id_art = :id_art";
                $stmtUpdateQuantite = $bdd->prepare($queryUpdateQuantite);
                $stmtUpdateQuantite->bindParam(':quantite', $quantite, PDO::PARAM_INT);
                $stmtUpdateQuantite->bindParam(':id_art', $id_art, PDO::PARAM_INT);
                $stmtUpdateQuantite->execute();
            } else {
                echo "Échec de la transmission. Erreur : " . implode(" ", $stmt->errorInfo());
            }
        }

        echo "<div class='vide'>Votre commande a bien été enregistrée.</div>";
        unset($_SESSION['panier']);
        ?>
        <button><a href='index.php'>Retour à l'accueil</a></button>
        <?php
    } else {
        echo "<div class='vide'>Votre panier est vide.</div>";
    }
} else {
    echo "<div class='vide'>Vous devez être connecté pour effectuer une commande.</div>";
}
?>

</body>
</html>
