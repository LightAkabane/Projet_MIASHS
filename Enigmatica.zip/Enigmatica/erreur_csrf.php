<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Erreur CSRF</title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
    <link rel="shortcut icon" href="images/icon.ico" />
</head>
<body class="ici">
    <h1>Erreur CSRF</h1>
    <p>Une erreur CSRF (Cross-Site Request Forgery) a été détectée. Veuillez ne pas tenter d'accéder à cette page directement.</p>
    <p><a href="index.php">Retour à la page d'accueil</a></p>
</body>
</html>
