<?php
require("bd.php");
$bdd = getBD();
try {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
    $sql = "DELETE FROM messages WHERE timestamp < NOW() - INTERVAL 10 MINUTE";
    $stmt = $bdd->prepare($sql);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo 'Messages plus anciens que 10 minutes supprimés avec succès.';
    } else {
        echo 'Aucun message plus ancien que 10 minutes à supprimer.';
    }
} catch (Exception $e) {
    echo 'Erreur : ' . $e->getMessage();
}

$bdd = null;
?>
