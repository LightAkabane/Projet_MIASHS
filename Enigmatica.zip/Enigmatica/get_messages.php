<?php
require("bd.php");
$pdo = getBD();

$query = $pdo->prepare("SELECT * FROM messages ORDER BY timestamp DESC LIMIT 10");
$query->execute();
$messages = $query->fetchAll(PDO::FETCH_ASSOC);

$messages = array_reverse($messages);

foreach ($messages as $message) {
    echo $message['user'] . ' dit \'' . $message['content'] . '\'<br>';
}
?>
