<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Enigmatica</title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" />
    <link rel="shortcut icon" href="images/icon.ico" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>
<a href="index.php"><img class="logo" src="images/logo.png"></img></a>
    <div class="session">
    
    <?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    session_start();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    if (isset($_SESSION['client'])) {
        echo '<div class ="salut">Bonjour ' . $_SESSION['client']['prenom'] . ' ' . $_SESSION['client']['nom'].'</div>';
        echo ' <br><button><a href="deconnexion.php">Se déconnecter</a></button><br>';
        echo '<br>';
        echo ' <button><a href="panier.php">Mon panier</a></button><br>';
        echo '<br>';
        echo ' <button><a href="historique.php">Mon historique</a></button><br>';
    
    ?>
    <div id="chat-window">
    <div id="chat-header" onclick="toggleChat()">Chat</div>
    <div id="chat-content">
        <div id="chat-messages"></div>
        <input type="text" id="message-input" placeholder="Entrez votre message...">
        <button id="bouton" onclick="sendMessage()">Envoyer</button>
    </div>
    
</div>
<?php
    }else{

        echo '<a href="nouveau.php"><button>Sinscrire</button> </a><br>';
        echo '<a href="connexion.php"><button>Se connecter</button></a><br>';
    }
?>
    </div>
    <table class="table1">
        <tr>
            <td>Image du Produit</td>
            <td>Numero Identifiant</td>
            <td>Nom du Personnage</td>
            <td>Stock</td>
            <td>Prix</td>
            <td></td>
        </tr>
        <?php
            include "bd.php";
            $bdd = getBD();
    
            $result = $bdd->query('SELECT url_photo, id_art, nom, quantite, prix FROM Article');
    
            while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                $image = $row['url_photo'];
                $ident = $row['id_art'];
                $nom = $row['nom'];
                $qtt = $row['quantite'];
                $prix = $row['prix'];
                ?>
                <tr>
                    <td><img src="<?php echo $image; ?>" alt="Image du Produit" class="zoom"></td>
                    <td><?php echo $ident; ?></td>
                    <td><?php echo $nom; ?></td>
                    <td><?php echo $qtt; ?></td>
                    <td><?php echo $prix; ?>¥</td>
                    <td><a href="articles/article.php?id_art=<?php echo $ident; ?>">Voir plus</a></td>
                </tr>
                <?php
            }
        ?>
    </table>
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <button> <a href="contact/Contact.html">Contactez-moi</a></button>

<script>
var chatContent = document.getElementById('chat-content');
var chatMessages = document.getElementById('chat-messages');
var messageInput = document.getElementById('message-input');
var messageSend =document.getElementById('bouton');

function toggleChat() {
    if (chatContent.style.maxHeight) {
        chatContent.style.maxHeight = null;
        chatMessages.style.display = 'none';
        messageInput.style.display = 'none';
        messageSend.style.display = 'none';
    } else {
        chatContent.style.maxHeight = '200px'; 
        chatMessages.style.display = 'block';
        messageInput.style.display = 'block';
        messageSend.style.display = 'block'
    }
}
    function getMessages() {
    $.ajax({
        url: 'get_messages.php',
        type: 'GET',
        success: function(response) {
            $('#chat-messages').html(response);
        }
    });
}

setInterval(function() {
        $.ajax({
            type: 'POST',
            url: 'delete_old_messages.php',
            success: function(response) {
                console.log('Messages anciens supprimés avec succès depuis PHP.');
            }
        });
}, 10000); 

function sendMessage() {
    var message = $('#message-input').val().trim();

    if (message.length === 0) {
        alert('Le message ne peut pas être vide.');
        return;
    }

    if (message.length > 256) {
        alert('Le message ne peut pas dépasser 256 caractères.');
        return;
    }

    $.ajax({
        url: 'send_messages.php',
        type: 'POST',
        data: { message: message },
        success: function (response) {
            if (response === 'offensive') {
                alert('Erreur : Le message est considéré comme offensant et n\'a pas été envoyé.');
            } else {
                $('#message-input').val('');
            }
        }
    });
}



setInterval(function() {
    getMessages();
}, 500);
$(document).ready(function() {
    getMessages();
});

</script>
</body>
</html>
