<head>
    <meta charset="UTF-8">
    <title><?php echo isset($nom) ? $nom : "Article"; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Climate+Crisis&family=Croissant+One&family=Fuggles&family=Tilt+Warp&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles/monfichier.css" type="text/css" media="screen" />
</head>
<body class="ici">
<?php
session_start();

$id_art = isset($_POST['id_art']) ? $_POST['id_art'] : null;
$quantite_article = isset($_POST['quantite_article']) ? $_POST['quantite_article'] : null;
$csrf_token = isset($_POST['csrf_token']) ? $_POST['csrf_token'] : '';

if ($id_art !== null && $quantite_article !== null && $csrf_token !== '' && hash_equals($_SESSION['csrf_token'], $csrf_token)) {
    include "bd.php";
    $bdd = getBD();

    $query = $bdd->prepare('SELECT * FROM Article WHERE id_art = :id_art');
    $query->bindParam(':id_art', $id_art, PDO::PARAM_INT);
    $query->execute();
    $article = $query->fetch(PDO::FETCH_ASSOC);

    if ($article) {
        $quantite_max = $article['quantite'];

        session_start();
        if (isset($_SESSION['client'])) {
            $client_id = $_SESSION['client']['id_client'];
            $panier = isset($_SESSION['panier']) ? $_SESSION['panier'] : array();

            foreach ($panier as $item) {
                if ($item['id_art'] == $id_art) {
                    $quantite_panier = $item['quantite'];
                    $quantite_max = min($quantite_max, $quantite_max - $quantite_panier);
                }
            }

            if ($quantite_article > 0 && $quantite_article <= $quantite_max) {
                $_SESSION['quantite_max'][$id_art] = $quantite_article;

                $article_existe = false;
                foreach ($_SESSION['panier'] as &$item) {
                    if ($item['id_art'] === $id_art) {
                        $item['quantite'] += $quantite_article;
                        $article_existe = true;
                        break;
                    }
                }

                if (!$article_existe) {
                    $nouvel_article = array(
                        'id_art' => $id_art,
                        'quantite' => $quantite_article
                    );
                    $_SESSION['panier'][] = $nouvel_article;
                }

                header('Location: index.php');
                exit();
            } else {
                echo "La quantité choisie n'est pas valide.";
                header('refresh:2;url=index.php');
                exit();
            }
        }
    }
} else {
    echo "Problème avec les données du formulaire.";
}
?>
</body>
