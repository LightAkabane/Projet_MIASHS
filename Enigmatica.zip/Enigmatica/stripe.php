<?php

require_once 'vendor/autoload.php';

$stripe_secret_key ='sk_test_51OG2WoHLcgDBShHXMN1FMPa00l3uQIzgumwpYgVm7DKMRO2LhTjDaJWnFed6dVd6AJ3sKPJnSg81NFVy4H6B8wui001qhDe8Wc';
$stripe_public_key ='pk_test_51OG2WoHLcgDBShHXSxdWxulCGdmuXPzVs1NuYTOUJbpfzXdoyHW1rhlonUFutFpGk7sib4zaP8bPGVAZHciiamhz00JCjniqLF';
$stripe = new \Stripe\StripeClient($stripe_secret_key);

?>
