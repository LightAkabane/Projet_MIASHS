<?php
session_start();
require("bd.php");
$bdd = getBD();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupérer les données du formulaire
    $message = $_POST['message'];
    $user = $_SESSION['client']['prenom'];

    // Charger la ScoreMap depuis le fichier JSON
    $scoreMapFile = 'score_map.json';
    $scoreMap = json_decode(file_get_contents($scoreMapFile), true);

    // Diviser le message en mots
    $messageWords = preg_split("/\s+/", $message);

    // Calculer le score total du message
    $totalScore = 0;
    foreach ($messageWords as $word) {
        if (isset($scoreMap[$word])) {
            $totalScore += $scoreMap[$word];
        }
    }

    // Vérifier si le message est considéré comme offensant
    $isOffensive = $totalScore < 0;

    if (!$isOffensive) {
        // Insérer le message dans la base de données
        $query = $bdd->prepare("INSERT INTO messages (user, content, timestamp) VALUES (?, ?, NOW())");
        $query->execute([$user, $message]);
        // Ajoutez ici d'autres traitements ou redirections si nécessaire
    } else {
        // Le message est offensant
        echo "offensive";
        // Vous pourriez ajouter des informations supplémentaires ou rediriger l'utilisateur
    }
}
?>
